=== OperStack AI Visibility ===
Contributors: operstack
Tags: ai, llms.txt, seo, schema, chatgpt
Requires at least: 6.4
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 0.2.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Shows how many visitors ChatGPT and Perplexity actually sent you, and makes your site readable and quotable by them.

== Description ==

When somebody asks ChatGPT or Perplexity a question your business answers, the assistant fetches a handful of pages and quotes them. If it cannot reach your site, cannot tell what your business is, or finds nothing worth quoting, it names somebody else.

= First it answers the question nobody can answer =

**How many people did ChatGPT actually send you last month?** Almost no site owner knows. In Google Analytics those visits hide under "direct" or sit as a referral from chatgpt.com that nobody opens. This plugin counts them on your own site and shows one small table: ChatGPT 12, Perplexity 3, Claude 1. Nothing about the visitor is stored, only which assistant and how many. If the answer is zero, you get a zero, which is also an answer.

= Then it fixes the part a machine can fix =

* **Lets the answer fetchers in.** OAI-SearchBot, ChatGPT-User, PerplexityBot, Perplexity-User, Claude-SearchBot, Claude-User, DuckAssistBot and Applebot are allowed in robots.txt. The training crawlers are left exactly as they are, because whether to feed them is your decision, not ours.
* **Publishes a map at /llms.txt.** A plain list of your pages with one line each, written for assistants rather than for people.
* **Publishes an agent card** at /.well-known/agent.json, so an automated caller can find out what this site is and where its map lives.
* **Adds business schema** with your real type: a dentist is marked as a dentist, a roofer as a roofing contractor, with your phone, address and hours.
* **Counts visits from ChatGPT, Perplexity, Claude, Copilot, Gemini and fourteen others**, with no analytics account to connect. It keeps working behind a page cache or a CDN, where anything counted while the page is built would miss most of the traffic.
* **Adds a meta description** where your theme leaves one out, and steps aside quietly if Yoast, Rank Math, AIOSEO or SEOPress is already doing it.

= Your assistant can do the setup =

Everything the plugin knows is readable and writable over the WordPress REST API. Create an application password in your profile, give it to Claude or another assistant, and ask it to set the site up. It will read what is missing, ask you for the facts it cannot know (your phone, your address, your hours), write them in, and tell you what it could not do.

The plugin never invents a fact about your business. If it does not know your phone number, it says so instead of guessing.

= What it does not do =

It does not write your pages, promise rankings, or send anything anywhere. It has no account, no key and no telemetry. If a robots.txt file exists in your site root, WordPress cannot override it, and the plugin says so plainly rather than pretending the setting worked.

== Frequently Asked Questions ==

= Will this conflict with my SEO plugin? =

No. It checks for Yoast, Rank Math, AIOSEO and SEOPress and does not write a second meta description over theirs.

= Does it block AI from training on my content? =

No, and it does not unblock it either. Training crawlers keep whatever rules you already had. This plugin only opens the fetchers that quote you in an answer, which is a different set.

= I do not see /llms.txt =

Visit Settings, then Permalinks, and press Save. WordPress rebuilds its address rules and the file appears.

== Changelog ==

= 0.2.1 =
* The visit counter no longer treats ordinary search as an AI assistant. Referrals from ya.ru and duckduckgo.com were being counted as Alice and DuckDuckGo AI, which inflated the number against what your analytics shows. Alice is alice.yandex.ru and the DuckDuckGo assistant is duck.ai; only those count now.
* Added Google AI Studio, DeepSeek, Meta AI and Phind.

= 0.2.0 =
* Counts visits from AI assistants on your own server, so the owner can finally see whether ChatGPT sends anyone.
* Settings screen with a plain-words state of every signal.

= 0.1.0 =
* First release.
