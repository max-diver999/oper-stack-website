<?php
/**
 * Plugin Name:       OperStack AI Visibility
 * Description:       Makes a WordPress site readable and quotable by AI assistants: AI fetcher access, an llms.txt map, an agent card, entity schema and answer-ready meta. Everything it writes is also writable by an assistant over the REST API, so the owner can simply ask Claude to fix the site.
 * Version:           0.2.0
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Author:            OperStack
 * Author URI:        https://oper-stack.com
 * License:           GPL-2.0-or-later
 * Text Domain:       operstack-ai-visibility
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'OPERSTACK_AIV_VERSION', '0.1.0' );
define( 'OPERSTACK_AIV_OPTION', 'operstack_aiv' );

/** Fetchers that pull a page to quote it in an answer. Blocking these costs citations. */
function operstack_aiv_search_agents() {
	return array( 'OAI-SearchBot', 'ChatGPT-User', 'PerplexityBot', 'Perplexity-User', 'Claude-SearchBot', 'Claude-User', 'DuckAssistBot', 'Applebot' );
}

/** Training crawlers. Whether to allow them is the owner's call, so the plugin never touches them. */
function operstack_aiv_training_agents() {
	return array( 'GPTBot', 'CCBot', 'ClaudeBot', 'Google-Extended', 'Applebot-Extended', 'anthropic-ai', 'Bytespider', 'meta-externalagent' );
}

function operstack_aiv_defaults() {
	return array(
		'allow_ai_search' => true,
		'llms_txt'        => true,
		'agent_card'      => true,
		'entity_schema'   => true,
		'meta_description'=> true,
		'business'        => array(
			'type' => 'LocalBusiness', 'phone' => '', 'email' => '', 'street' => '',
			'city' => '', 'region' => '', 'postal' => '', 'country' => '', 'profiles' => array(), 'hours' => '',
		),
	);
}

function operstack_aiv_get( $key = null ) {
	$o = wp_parse_args( get_option( OPERSTACK_AIV_OPTION, array() ), operstack_aiv_defaults() );
	$o['business'] = wp_parse_args( isset( $o['business'] ) ? $o['business'] : array(), operstack_aiv_defaults()['business'] );
	return null === $key ? $o : ( isset( $o[ $key ] ) ? $o[ $key ] : null );
}

/* ---------------------------------------------------------------- robots.txt */

add_filter( 'robots_txt', 'operstack_aiv_robots', 20, 2 );
function operstack_aiv_robots( $output, $public ) {
	if ( ! operstack_aiv_get( 'allow_ai_search' ) || ! $public ) { return $output; }
	$lines = array( '', '# OperStack: AI answer fetchers, allowed so this site can be quoted' );
	foreach ( operstack_aiv_search_agents() as $agent ) {
		$lines[] = 'User-agent: ' . $agent;
		$lines[] = 'Allow: /';
		$lines[] = '';
	}
	$lines[] = '# Map for assistants: ' . esc_url( home_url( '/llms.txt' ) );
	return $output . implode( "\n", $lines ) . "\n";
}

/** A physical robots.txt in the web root silently wins over everything WordPress does. */
function operstack_aiv_physical_robots() {
	$path = ABSPATH . 'robots.txt';
	return file_exists( $path ) ? $path : false;
}

/* ---------------------------------------------------------------- llms.txt and the agent card */

add_action( 'init', 'operstack_aiv_rewrites' );
function operstack_aiv_rewrites() {
	add_rewrite_rule( '^llms\.txt$', 'index.php?operstack_aiv=llms', 'top' );
	add_rewrite_rule( '^\.well-known/agent\.json$', 'index.php?operstack_aiv=agent', 'top' );
}

add_filter( 'query_vars', function ( $vars ) { $vars[] = 'operstack_aiv'; return $vars; } );

add_filter( 'redirect_canonical', 'operstack_aiv_no_canonical', 10, 2 );
function operstack_aiv_no_canonical( $redirect, $requested ) {
	// WordPress adds a trailing slash to anything it does not recognise, turning /llms.txt into a 301.
	return get_query_var( 'operstack_aiv' ) ? false : $redirect;
}

add_action( 'template_redirect', 'operstack_aiv_serve', 0 );
function operstack_aiv_serve() {
	$what = get_query_var( 'operstack_aiv' );
	if ( 'llms' === $what && operstack_aiv_get( 'llms_txt' ) ) {
		status_header( 200 );
		header( 'Content-Type: text/plain; charset=utf-8' );
		echo operstack_aiv_build_llms(); // phpcs:ignore WordPress.Security.EscapeOutput
		exit;
	}
	if ( 'agent' === $what && operstack_aiv_get( 'agent_card' ) ) {
		status_header( 200 );
		header( 'Content-Type: application/json; charset=utf-8' );
		echo wp_json_encode( operstack_aiv_build_agent_card(), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
		exit;
	}
}

/** The map an assistant reads: what this site is, and which pages are worth opening. */
function operstack_aiv_build_llms() {
	$name = get_bloginfo( 'name' );
	$desc = get_bloginfo( 'description' );
	$out  = "# {$name}\n\n";
	if ( $desc ) { $out .= "> {$desc}\n\n"; }
	$out .= "Updated: " . gmdate( 'Y-m-d' ) . "\n\n## Pages\n\n";
	$q = new WP_Query( array(
		'post_type'      => array( 'page', 'post' ),
		'post_status'    => 'publish',
		'posts_per_page' => 200,
		'orderby'        => 'menu_order title',
		'order'          => 'ASC',
		'no_found_rows'  => true,
	) );
	foreach ( $q->posts as $p ) {
		if ( get_post_meta( $p->ID, '_operstack_aiv_exclude', true ) ) { continue; }
		$summary = operstack_aiv_summary( $p );
		$out    .= '- [' . wp_strip_all_tags( get_the_title( $p ) ) . '](' . get_permalink( $p ) . ')';
		if ( $summary ) { $out .= ': ' . $summary; }
		$out .= "\n";
	}
	return $out;
}

function operstack_aiv_summary( $p, $len = 160 ) {
	$text = $p->post_excerpt ? $p->post_excerpt : wp_strip_all_tags( strip_shortcodes( $p->post_content ) );
	$text = trim( preg_replace( '/\s+/', ' ', $text ) );
	if ( '' === $text ) { return ''; }
	return rtrim( mb_substr( $text, 0, $len ), " \t\n\r.," ) . ( mb_strlen( $text ) > $len ? '…' : '' );
}

function operstack_aiv_build_agent_card() {
	$b = operstack_aiv_get( 'business' );
	$card = array(
		'name'        => get_bloginfo( 'name' ),
		'description' => get_bloginfo( 'description' ),
		'url'         => home_url( '/' ),
		'documentation' => home_url( '/llms.txt' ),
		'sitemap'     => home_url( '/wp-sitemap.xml' ),
		'updated'     => gmdate( 'c' ),
		'generator'   => 'operstack-ai-visibility/' . OPERSTACK_AIV_VERSION,
	);
	if ( $b['email'] ) { $card['contact'] = $b['email']; }
	if ( $b['phone'] ) { $card['telephone'] = $b['phone']; }
	return $card;
}

/* ---------------------------------------------------------------- head: schema and meta */

add_action( 'wp_head', 'operstack_aiv_head', 5 );
function operstack_aiv_head() {
	$o = operstack_aiv_get();
	if ( $o['meta_description'] && ! operstack_aiv_other_seo_plugin() ) {
		$d = operstack_aiv_description();
		if ( $d ) { echo '<meta name="description" content="' . esc_attr( $d ) . '" />' . "\n"; }
	}
	if ( $o['entity_schema'] ) {
		$graph = operstack_aiv_schema_graph();
		if ( $graph ) {
			echo '<script type="application/ld+json">' . wp_json_encode( $graph, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
		}
	}
	echo '<link rel="alternate" type="text/markdown" href="' . esc_url( home_url( '/llms.txt' ) ) . '" title="Map for AI assistants" />' . "\n";
}

/** Never fight another SEO plugin over the same tag: two descriptions are worse than one. */
function operstack_aiv_other_seo_plugin() {
	return defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' );
}

function operstack_aiv_description() {
	if ( is_front_page() ) {
		$d = get_bloginfo( 'description' );
		return $d ? $d : operstack_aiv_summary( get_post( get_option( 'page_on_front' ) ), 155 );
	}
	if ( is_singular() ) { return operstack_aiv_summary( get_queried_object(), 155 ); }
	return '';
}

function operstack_aiv_schema_graph() {
	$b     = operstack_aiv_get( 'business' );
	$type  = $b['type'] ? $b['type'] : 'LocalBusiness';
	$node  = array(
		'@type' => $type,
		'@id'   => home_url( '/#business' ),
		'name'  => get_bloginfo( 'name' ),
		'url'   => home_url( '/' ),
	);
	if ( get_bloginfo( 'description' ) ) { $node['description'] = get_bloginfo( 'description' ); }
	if ( $b['phone'] ) { $node['telephone'] = $b['phone']; }
	if ( $b['email'] ) { $node['email'] = $b['email']; }
	if ( $b['hours'] ) { $node['openingHours'] = $b['hours']; }
	if ( $b['street'] || $b['city'] ) {
		$node['address'] = array_filter( array(
			'@type'           => 'PostalAddress',
			'streetAddress'   => $b['street'],
			'addressLocality' => $b['city'],
			'addressRegion'   => $b['region'],
			'postalCode'      => $b['postal'],
			'addressCountry'  => $b['country'],
		) );
	}
	if ( ! empty( $b['profiles'] ) ) { $node['sameAs'] = array_values( $b['profiles'] ); }

	$graph = array( $node );
	if ( is_singular() && ! is_front_page() ) {
		$p       = get_queried_object();
		$graph[] = array(
			'@type'         => 'WebPage',
			'@id'           => get_permalink( $p ) . '#page',
			'name'          => wp_strip_all_tags( get_the_title( $p ) ),
			'url'           => get_permalink( $p ),
			'datePublished' => get_the_date( 'c', $p ),
			'dateModified'  => get_the_modified_date( 'c', $p ),
			'isPartOf'      => array( '@id' => home_url( '/#business' ) ),
		);
	}
	return array( '@context' => 'https://schema.org', '@graph' => $graph );
}

/* ---------------------------------------------------------------- AI referrals */

/**
 * Counts visits that arrived from an AI assistant, by day and by source. No personal data is
 * stored: the referring host and a count, nothing else. The owner asks "does ChatGPT send me
 * anyone" and finally has an answer without connecting analytics to anything.
 */
function operstack_aiv_ai_sources() {
	return array(
		'chatgpt.com' => 'ChatGPT', 'chat.openai.com' => 'ChatGPT', 'openai.com' => 'ChatGPT',
		'perplexity.ai' => 'Perplexity', 'www.perplexity.ai' => 'Perplexity',
		'claude.ai' => 'Claude', 'copilot.microsoft.com' => 'Copilot', 'copilot.com' => 'Copilot',
		'gemini.google.com' => 'Gemini', 'notebooklm.google.com' => 'NotebookLM',
		'you.com' => 'You.com', 'chat.qwen.ai' => 'Qwen', 'doubao.com' => 'Doubao',
		'alice.yandex.ru' => 'Alice', 'ya.ru' => 'Alice', 'chat.mistral.ai' => 'Le Chat',
		'grok.com' => 'Grok', 'x.ai' => 'Grok', 'duckduckgo.com' => 'DuckDuckGo AI',
	);
}

/**
 * Counting happens in the visitor's browser, not while the page is built, and that is deliberate.
 * Half of WordPress sites sit behind a page cache or a CDN: the HTML is served without PHP running
 * at all, so anything counted during the render would miss most of the traffic and quietly report
 * a number far too low. A three-line script fires only when the visitor came from an assistant,
 * which means one extra request for those visits and none for everybody else.
 */
add_action( 'wp_footer', 'operstack_aiv_beacon', 99 );
function operstack_aiv_beacon() {
	if ( is_admin() || is_user_logged_in() ) { return; }
	$hosts = array_keys( operstack_aiv_ai_sources() );
	$url   = esc_url_raw( rest_url( 'operstack/v1/hit' ) );
	?>
<script id="operstack-aiv">(function(){try{var r=document.referrer;if(!r)return;var h=new URL(r).hostname.replace(/^www\./,'').toLowerCase();var k=<?php echo wp_json_encode( $hosts ); ?>;if(k.indexOf(h)<0)return;if(sessionStorage.getItem('op_aiv'))return;sessionStorage.setItem('op_aiv','1');fetch(<?php echo wp_json_encode( $url ); ?>,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({from:h}),keepalive:true}).catch(function(){});}catch(e){}})();</script>
	<?php
}

/** Records one visit from one assistant. Public by design: it stores a name and a number. */
function operstack_aiv_count_from( $host ) {
	$host = strtolower( preg_replace( '/^www\./', '', (string) $host ) );
	$name = null;
	foreach ( operstack_aiv_ai_sources() as $needle => $label ) {
		if ( $host === preg_replace( '/^www\./', '', $needle ) ) { $name = $label; break; }
	}
	if ( ! $name ) { return false; }

	$log = get_option( 'operstack_aiv_referrals', array() );
	$day = gmdate( 'Y-m-d' );
	if ( ! isset( $log[ $day ] ) ) { $log[ $day ] = array(); }
	$log[ $day ][ $name ] = isset( $log[ $day ][ $name ] ) ? (int) $log[ $day ][ $name ] + 1 : 1;

	// Ninety days is enough to answer the question and keeps the row small.
	if ( count( $log ) > 90 ) {
		ksort( $log );
		$log = array_slice( $log, -90, null, true );
	}
	update_option( 'operstack_aiv_referrals', $log, false );
	return $name;
}

/** Totals per assistant over the last N days, biggest first. */
function operstack_aiv_referral_totals( $days = 30 ) {
	$log   = get_option( 'operstack_aiv_referrals', array() );
	$from  = gmdate( 'Y-m-d', time() - $days * DAY_IN_SECONDS );
	$total = array();
	foreach ( $log as $day => $sources ) {
		if ( $day < $from ) { continue; }
		foreach ( $sources as $name => $n ) {
			$total[ $name ] = isset( $total[ $name ] ) ? $total[ $name ] + (int) $n : (int) $n;
		}
	}
	arsort( $total );
	return $total;
}

/* ---------------------------------------------------------------- REST: what an assistant drives */

add_action( 'rest_api_init', 'operstack_aiv_rest' );
function operstack_aiv_rest() {
	$perm = function () { return current_user_can( 'manage_options' ); };

	register_rest_route( 'operstack/v1', '/status', array(
		'methods'             => 'GET',
		'permission_callback' => $perm,
		'callback'            => function () {
			$o = operstack_aiv_get();
			return array(
				'version'         => OPERSTACK_AIV_VERSION,
				'settings'        => $o,
				'llms_txt_url'    => home_url( '/llms.txt' ),
				'agent_card_url'  => home_url( '/.well-known/agent.json' ),
				'sitemap_url'     => home_url( '/wp-sitemap.xml' ),
				'other_seo_plugin'=> operstack_aiv_other_seo_plugin(),
				'physical_robots' => operstack_aiv_physical_robots() ? 'A robots.txt file exists in the site root and overrides WordPress. Delete it, or edit it by hand, or the AI fetcher rules below will not apply.' : false,
				'missing_facts'   => operstack_aiv_missing_facts(),
				'ai_referrals_30d'=> operstack_aiv_referral_totals( 30 ),
			);
		},
	) );

	register_rest_route( 'operstack/v1', '/settings', array(
		'methods'             => 'POST',
		'permission_callback' => $perm,
		'callback'            => 'operstack_aiv_rest_save',
	) );

	register_rest_route( 'operstack/v1', '/hit', array(
		'methods'             => 'POST',
		// Открыт намеренно: это счётчик визитов на собственном сайте владельца, он ничего не отдаёт
		// и ничего не знает о посетителе. Закрывать его ключом значило бы не считать вовсе.
		'permission_callback' => '__return_true',
		'callback'            => function ( WP_REST_Request $req ) {
			$from = $req->get_param( 'from' );
			if ( ! $from ) {
				$ref  = $req->get_header( 'referer' );
				$from = $ref ? wp_parse_url( $ref, PHP_URL_HOST ) : '';
			}
			$name = operstack_aiv_count_from( $from );
			return new WP_REST_Response( array( 'counted' => (bool) $name ), 204 );
		},
	) );

	register_rest_route( 'operstack/v1', '/flush', array(
		'methods'             => 'POST',
		'permission_callback' => $perm,
		'callback'            => function () { operstack_aiv_rewrites(); flush_rewrite_rules( false ); return array( 'flushed' => true ); },
	) );
}

/** What the plugin cannot know and must be told, so an assistant asks the owner instead of inventing. */
function operstack_aiv_missing_facts() {
	$b       = operstack_aiv_get( 'business' );
	$missing = array();
	if ( ! $b['phone'] )  { $missing['phone']    = 'A phone number a customer can call.'; }
	if ( ! $b['email'] )  { $missing['email']    = 'An email address a customer can write to.'; }
	if ( ! $b['city'] )   { $missing['address']  = 'Street, city, region, postcode and country, if customers come to you.'; }
	if ( ! $b['hours'] )  { $missing['hours']    = 'Opening hours, in the form Mo-Fr 09:00-18:00.'; }
	if ( empty( $b['profiles'] ) ) { $missing['profiles'] = 'Links to your own profiles: Google Business, Facebook, Instagram, LinkedIn.'; }
	return $missing;
}

function operstack_aiv_rest_save( WP_REST_Request $req ) {
	$in  = $req->get_json_params();
	$o   = operstack_aiv_get();
	foreach ( array( 'allow_ai_search', 'llms_txt', 'agent_card', 'entity_schema', 'meta_description' ) as $flag ) {
		if ( isset( $in[ $flag ] ) ) { $o[ $flag ] = (bool) $in[ $flag ]; }
	}
	if ( isset( $in['business'] ) && is_array( $in['business'] ) ) {
		$b = $o['business'];
		foreach ( array( 'type', 'phone', 'email', 'street', 'city', 'region', 'postal', 'country', 'hours' ) as $k ) {
			if ( isset( $in['business'][ $k ] ) ) { $b[ $k ] = sanitize_text_field( $in['business'][ $k ] ); }
		}
		if ( isset( $in['business']['profiles'] ) && is_array( $in['business']['profiles'] ) ) {
			$b['profiles'] = array_values( array_filter( array_map( 'esc_url_raw', $in['business']['profiles'] ) ) );
		}
		$o['business'] = $b;
	}
	update_option( OPERSTACK_AIV_OPTION, $o );
	return array( 'saved' => true, 'settings' => operstack_aiv_get(), 'missing_facts' => operstack_aiv_missing_facts() );
}

/* ---------------------------------------------------------------- admin screen */

add_action( 'admin_menu', 'operstack_aiv_menu' );
function operstack_aiv_menu() {
	add_options_page(
		__( 'AI Visibility', 'operstack-ai-visibility' ),
		__( 'AI Visibility', 'operstack-ai-visibility' ),
		'manage_options',
		'operstack-ai-visibility',
		'operstack_aiv_screen'
	);
}

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function ( $links ) {
	$url = admin_url( 'options-general.php?page=operstack-ai-visibility' );
	array_unshift( $links, '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Settings', 'operstack-ai-visibility' ) . '</a>' );
	return $links;
} );

/** Reads this site the way an assistant would, so the owner sees the state rather than a form. */
function operstack_aiv_self_check() {
	$o    = operstack_aiv_get();
	$b    = $o['business'];
	$rows = array();

	$physical = operstack_aiv_physical_robots();
	$rows[]   = array(
		'label' => __( 'AI answer fetchers allowed', 'operstack-ai-visibility' ),
		'state' => $physical ? 'blocked' : ( $o['allow_ai_search'] ? 'ok' : 'off' ),
		'note'  => $physical
			? __( 'A robots.txt file sits in your site root. WordPress cannot override it, so these rules are not applied. Delete that file, or paste the lines below into it by hand.', 'operstack-ai-visibility' )
			: __( 'OAI-SearchBot, ChatGPT-User, PerplexityBot, Perplexity-User, Claude-SearchBot, Claude-User, DuckAssistBot and Applebot can reach your pages.', 'operstack-ai-visibility' ),
	);
	$rows[] = array(
		'label' => __( 'Map for assistants at /llms.txt', 'operstack-ai-visibility' ),
		'state' => $o['llms_txt'] ? 'ok' : 'off',
		'note'  => $o['llms_txt']
			/* translators: %s: the llms.txt address of this site. */
			? sprintf( __( 'Published at %s and rebuilt as you publish pages.', 'operstack-ai-visibility' ), home_url( '/llms.txt' ) )
			: __( 'Switched off. Assistants have no list of your pages.', 'operstack-ai-visibility' ),
	);
	$rows[] = array(
		'label' => __( 'Agent card', 'operstack-ai-visibility' ),
		'state' => $o['agent_card'] ? 'ok' : 'off',
		'note'  => __( 'A machine asking what this site is finds the answer at /.well-known/agent.json.', 'operstack-ai-visibility' ),
	);

	$missing = operstack_aiv_missing_facts();
	$rows[]  = array(
		'label' => __( 'Business details in the page code', 'operstack-ai-visibility' ),
		'state' => empty( $missing ) ? 'ok' : ( $b['phone'] || $b['city'] ? 'partial' : 'off' ),
		'note'  => empty( $missing )
			/* translators: %s: the schema.org type describing this business. */
			? sprintf( __( 'Published as %s with your contact details, so an assistant knows what this business is.', 'operstack-ai-visibility' ), $b['type'] )
			: __( 'Still missing: ', 'operstack-ai-visibility' ) . implode( ', ', array_keys( $missing ) ),
	);

	if ( operstack_aiv_other_seo_plugin() ) {
		$rows[] = array(
			'label' => __( 'Meta description', 'operstack-ai-visibility' ),
			'state' => 'ok',
			'note'  => __( 'Left to your SEO plugin, which was already writing it. Two descriptions on one page are worse than one.', 'operstack-ai-visibility' ),
		);
	}
	return $rows;
}

function operstack_aiv_screen() {
	if ( ! current_user_can( 'manage_options' ) ) { return; }

	if ( isset( $_POST['operstack_aiv_nonce'] ) && wp_verify_nonce( sanitize_key( wp_unslash( $_POST['operstack_aiv_nonce'] ) ), 'operstack_aiv_save' ) ) {
		$o = operstack_aiv_get();
		foreach ( array( 'allow_ai_search', 'llms_txt', 'agent_card', 'entity_schema', 'meta_description' ) as $flag ) {
			$o[ $flag ] = isset( $_POST[ $flag ] );
		}
		foreach ( array( 'type', 'phone', 'email', 'street', 'city', 'region', 'postal', 'country', 'hours' ) as $k ) {
			if ( isset( $_POST[ $k ] ) ) { $o['business'][ $k ] = sanitize_text_field( wp_unslash( $_POST[ $k ] ) ); }
		}
		if ( isset( $_POST['profiles'] ) ) {
			$lines            = preg_split( '/\R/', sanitize_textarea_field( wp_unslash( $_POST['profiles'] ) ) );
			$o['business']['profiles'] = array_values( array_filter( array_map( 'esc_url_raw', array_map( 'trim', $lines ) ) ) );
		}
		update_option( OPERSTACK_AIV_OPTION, $o );
		operstack_aiv_rewrites();
		flush_rewrite_rules( false );
		echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Saved.', 'operstack-ai-visibility' ) . '</p></div>';
	}

	$o = operstack_aiv_get();
	$b = $o['business'];
	$labels = array( 'ok' => __( 'done', 'operstack-ai-visibility' ), 'off' => __( 'off', 'operstack-ai-visibility' ), 'partial' => __( 'half done', 'operstack-ai-visibility' ), 'blocked' => __( 'blocked', 'operstack-ai-visibility' ) );
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'AI Visibility', 'operstack-ai-visibility' ); ?></h1>
		<p style="max-width:70ch"><?php esc_html_e( 'When somebody asks ChatGPT or Perplexity a question your business answers, the assistant fetches a few pages and quotes them. This page shows whether yours can be fetched, understood and quoted.', 'operstack-ai-visibility' ); ?></p>

		<h2><?php esc_html_e( 'Visits AI assistants sent you', 'operstack-ai-visibility' ); ?></h2>
		<?php
		$refs  = operstack_aiv_referral_totals( 30 );
		$since = get_option( 'operstack_aiv_counting_since' );
		if ( ! $since ) { $since = gmdate( 'Y-m-d' ); update_option( 'operstack_aiv_counting_since', $since ); }
		if ( empty( $refs ) ) : ?>
			<p style="max-width:70ch">
				<?php
				printf(
					/* translators: %s: the date counting started. */
					esc_html__( 'None yet. Counting started on %s, and this is a real answer rather than a missing one: if nobody has arrived from ChatGPT, Perplexity, Claude, Copilot or Gemini, the number is zero and you now know it. Give it a couple of weeks.', 'operstack-ai-visibility' ),
					esc_html( $since )
				);
				?>
			</p>
		<?php else : ?>
			<table class="widefat striped" style="max-width:420px">
				<thead><tr><th><?php esc_html_e( 'Assistant', 'operstack-ai-visibility' ); ?></th><th><?php esc_html_e( 'Visits, last 30 days', 'operstack-ai-visibility' ); ?></th></tr></thead>
				<tbody>
				<?php foreach ( $refs as $name => $n ) : ?>
					<tr><td><?php echo esc_html( $name ); ?></td><td><?php echo esc_html( number_format_i18n( $n ) ); ?></td></tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<p class="description" style="max-width:70ch"><?php esc_html_e( 'Counted on your own site, and stored on it: only the name of the assistant and a number, nothing about the visitor, no cookie, nothing sent anywhere. A visit is counted once even if the person reads five pages. Somebody browsing with JavaScript switched off is not counted, which is a handful of people in a hundred.', 'operstack-ai-visibility' ); ?></p>
		<?php endif; ?>

		<h2><?php esc_html_e( 'Where you stand', 'operstack-ai-visibility' ); ?></h2>
		<table class="widefat striped" style="max-width:860px">
			<tbody>
			<?php foreach ( operstack_aiv_self_check() as $row ) : ?>
				<tr>
					<td style="width:34%"><strong><?php echo esc_html( $row['label'] ); ?></strong></td>
					<td style="width:12%"><?php echo esc_html( isset( $labels[ $row['state'] ] ) ? $labels[ $row['state'] ] : $row['state'] ); ?></td>
					<td><?php echo esc_html( $row['note'] ); ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>

		<?php if ( operstack_aiv_physical_robots() ) : ?>
			<h2><?php esc_html_e( 'Paste these lines into your robots.txt', 'operstack-ai-visibility' ); ?></h2>
			<p style="max-width:70ch"><?php esc_html_e( 'Your site root has its own robots.txt file, which WordPress cannot change. Open it in your hosting file manager and add this at the end:', 'operstack-ai-visibility' ); ?></p>
			<textarea readonly rows="10" style="width:100%;max-width:640px;font-family:monospace"><?php
				echo esc_textarea( operstack_aiv_robots( '', true ) );
			?></textarea>
		<?php endif; ?>

		<form method="post">
			<?php wp_nonce_field( 'operstack_aiv_save', 'operstack_aiv_nonce' ); ?>

			<h2><?php esc_html_e( 'Your business', 'operstack-ai-visibility' ); ?></h2>
			<p style="max-width:70ch"><?php esc_html_e( 'These go into the page code so an assistant can state who you are. Nothing here is guessed: what you leave empty stays absent.', 'operstack-ai-visibility' ); ?></p>
			<table class="form-table" role="presentation">
				<tr><th scope="row"><label for="op_type"><?php esc_html_e( 'What kind of business', 'operstack-ai-visibility' ); ?></label></th>
					<td><input name="type" id="op_type" type="text" class="regular-text" value="<?php echo esc_attr( $b['type'] ); ?>" />
					<p class="description"><?php esc_html_e( 'The most specific word that fits, in schema.org terms: Dentist, Plumber, RoofingContractor, Restaurant, Attorney, BeautySalon. A specific word beats a general one.', 'operstack-ai-visibility' ); ?></p></td></tr>
				<tr><th scope="row"><label for="op_phone"><?php esc_html_e( 'Phone', 'operstack-ai-visibility' ); ?></label></th>
					<td><input name="phone" id="op_phone" type="text" class="regular-text" value="<?php echo esc_attr( $b['phone'] ); ?>" /></td></tr>
				<tr><th scope="row"><label for="op_email"><?php esc_html_e( 'Email', 'operstack-ai-visibility' ); ?></label></th>
					<td><input name="email" id="op_email" type="text" class="regular-text" value="<?php echo esc_attr( $b['email'] ); ?>" /></td></tr>
				<tr><th scope="row"><label for="op_street"><?php esc_html_e( 'Street', 'operstack-ai-visibility' ); ?></label></th>
					<td><input name="street" id="op_street" type="text" class="regular-text" value="<?php echo esc_attr( $b['street'] ); ?>" /></td></tr>
				<tr><th scope="row"><label for="op_city"><?php esc_html_e( 'City', 'operstack-ai-visibility' ); ?></label></th>
					<td><input name="city" id="op_city" type="text" class="regular-text" value="<?php echo esc_attr( $b['city'] ); ?>" />
					<input name="region" type="text" class="regular-text" style="max-width:90px" value="<?php echo esc_attr( $b['region'] ); ?>" placeholder="<?php esc_attr_e( 'region', 'operstack-ai-visibility' ); ?>" />
					<input name="postal" type="text" class="regular-text" style="max-width:110px" value="<?php echo esc_attr( $b['postal'] ); ?>" placeholder="<?php esc_attr_e( 'postcode', 'operstack-ai-visibility' ); ?>" />
					<input name="country" type="text" class="regular-text" style="max-width:70px" value="<?php echo esc_attr( $b['country'] ); ?>" placeholder="<?php esc_attr_e( 'country', 'operstack-ai-visibility' ); ?>" /></td></tr>
				<tr><th scope="row"><label for="op_hours"><?php esc_html_e( 'Opening hours', 'operstack-ai-visibility' ); ?></label></th>
					<td><input name="hours" id="op_hours" type="text" class="regular-text" value="<?php echo esc_attr( $b['hours'] ); ?>" placeholder="Mo-Fr 09:00-18:00" /></td></tr>
				<tr><th scope="row"><label for="op_profiles"><?php esc_html_e( 'Your own profiles', 'operstack-ai-visibility' ); ?></label></th>
					<td><textarea name="profiles" id="op_profiles" rows="4" class="large-text" placeholder="https://..."><?php echo esc_textarea( implode( "\n", $b['profiles'] ) ); ?></textarea>
					<p class="description"><?php esc_html_e( 'One address per line: Google Business, Facebook, Instagram, LinkedIn. These tell an assistant that the business on this site and the business in those listings are the same one.', 'operstack-ai-visibility' ); ?></p></td></tr>
			</table>

			<h2><?php esc_html_e( 'What to publish', 'operstack-ai-visibility' ); ?></h2>
			<table class="form-table" role="presentation">
				<?php
				$flags = array(
					'allow_ai_search'  => __( 'Let AI answer fetchers read the site', 'operstack-ai-visibility' ),
					'llms_txt'         => __( 'Publish the map at /llms.txt', 'operstack-ai-visibility' ),
					'agent_card'       => __( 'Publish the agent card', 'operstack-ai-visibility' ),
					'entity_schema'    => __( 'Put the business details into the page code', 'operstack-ai-visibility' ),
					'meta_description' => __( 'Write a meta description where the theme leaves none', 'operstack-ai-visibility' ),
				);
				foreach ( $flags as $k => $label ) : ?>
					<tr><th scope="row"><?php echo esc_html( $label ); ?></th>
						<td><label><input type="checkbox" name="<?php echo esc_attr( $k ); ?>" <?php checked( ! empty( $o[ $k ] ) ); ?> /> <?php esc_html_e( 'on', 'operstack-ai-visibility' ); ?></label></td></tr>
				<?php endforeach; ?>
			</table>

			<?php submit_button(); ?>
		</form>

		<h2><?php esc_html_e( 'Let an assistant do this for you', 'operstack-ai-visibility' ); ?></h2>
		<p style="max-width:70ch"><?php esc_html_e( 'Everything on this page is also readable and writable over the WordPress REST API, so you can hand the work to Claude or another assistant instead of filling the form. Create an application password in your profile, give it to the assistant, and ask it to set the site up. It will read what is missing and ask you for the facts it cannot know.', 'operstack-ai-visibility' ); ?></p>
		<p><code>GET <?php echo esc_html( home_url( '/wp-json/operstack/v1/status' ) ); ?></code></p>

		<h2><?php esc_html_e( 'What this plugin does not check', 'operstack-ai-visibility' ); ?></h2>
		<p style="max-width:70ch"><?php esc_html_e( 'It fixes the plumbing. It cannot tell you whether your pages answer the questions your buyers actually ask, whether an assistant names you or a competitor, or whether your opening paragraphs can be quoted at all. A free check that reads your site from the outside and scores those is at oper-stack.com/ai-visibility, and it needs no account.', 'operstack-ai-visibility' ); ?></p>
	</div>
	<?php
}

/* ---------------------------------------------------------------- activation */

register_activation_hook( __FILE__, function () {
	operstack_aiv_rewrites();
	flush_rewrite_rules( false );
	if ( false === get_option( OPERSTACK_AIV_OPTION ) ) { add_option( OPERSTACK_AIV_OPTION, operstack_aiv_defaults() ); }
} );
register_deactivation_hook( __FILE__, function () { flush_rewrite_rules( false ); } );
