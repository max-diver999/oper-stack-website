<?php
/**
 * Removes what the plugin stored. Nothing else on the site is touched: pages the owner wrote,
 * or files the owner edited by hand, are theirs and stay.
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) { exit; }
delete_option( 'operstack_aiv' );
delete_option( 'operstack_aiv_referrals' );
delete_option( 'operstack_aiv_counting_since' );
delete_metadata( 'post', 0, '_operstack_aiv_exclude', '', true );
